import Foundation

func getData(urlRequest: String) {
    let urlRequest = URL(string: urlRequest)
    guard let url = urlRequest else { return }
    
    let configuration = URLSessionConfiguration.default
    configuration.timeoutIntervalForResource = 10
    configuration.waitsForConnectivity = true
    let session = URLSession(configuration: configuration)
    let task = session.dataTask(with: url) { data, response, error in
        if let error = error {
            print(error)
            return
        }
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            print("Кажется твой адрес неверный!")
            return
        }
        
        guard let data = data, let dataAsString = String(data: data, encoding: .utf8) else {
            return
        }
        
        print(httpResponse)
        print(dataAsString)
    }
    
    task.resume()
}

getData(urlRequest: "https://api.disneyapi.dev/characters")


